<td>
  <input type='checkbox' id='<?php echo $option['id'] ?>' name='<?php echo $option['id'] ?>' <?php checked(get_option($option['id'])) ?>'>
</td>
