<td>
  <input type='text' id='<?php echo $option['id'] ?>' name='<?php echo $option['id'] ?>' value='<?php echo get_option($option['id']) ?>'>
</td>
