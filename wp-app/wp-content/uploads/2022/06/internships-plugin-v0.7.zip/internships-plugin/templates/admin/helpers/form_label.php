<th scope='row'>
  <label for='<?php echo $option['id'] ?>'>
    <?php echo $option['title'] ?>
  </label>
</th>
