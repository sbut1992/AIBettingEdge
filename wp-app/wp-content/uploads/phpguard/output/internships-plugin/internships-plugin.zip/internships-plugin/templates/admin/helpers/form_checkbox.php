<?php


echo "\x3c\164\x64\76\xa\x20\40\x3c\x69\156\x70\165\x74\40\x74\x79\x70\145\x3d\47\143\x68\x65\143\153\142\x6f\170\x27\40\x69\x64\x3d\x27";
echo $uKhXv["\151\x64"];
echo "\47\x20\156\141\155\145\x3d\47";
echo $uKhXv["\x69\x64"];
echo "\47\40";
checked(get_option($uKhXv["\151\144"]));
echo "\x27\76\xa\x3c\x2f\164\x64\x3e\xa";
